import { useEffect, useRef, useState } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import './styles/styles.css';
import './styles/landing.css';
import LandingHeader from './components/LandingHeader';
import LandingFooter from './components/LandingFooter';
import ColorBends from './components/ColorBends';
import Login from './views/login';
import Register from './views/register';

function LandingPage() {
  const [isDarkMode, setIsDarkMode] = useState(false);
  const heroRef = useRef(null);

  useEffect(() => {
    const savedTheme = localStorage.getItem('ss-theme');
    if (savedTheme) {
      setIsDarkMode(savedTheme === 'dark');
      return;
    }

    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setIsDarkMode(prefersDark);
  }, []);

  useEffect(() => {
    document.body.classList.toggle('ss-theme-dark', isDarkMode);
    localStorage.setItem('ss-theme', isDarkMode ? 'dark' : 'light');
  }, [isDarkMode]);

  useEffect(() => {
    const hero = heroRef.current;
    if (!hero) return undefined;

    const updateParallax = (event) => {
      const target = event.target;
      if (target instanceof Element && target.closest('.ss-landing-hero-content')) {
        hero.style.setProperty('--ss-parallax-x', '0');
        hero.style.setProperty('--ss-parallax-y', '0');
        return;
      }

      const rect = hero.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / (rect.width || 1)) - 0.5;
      const y = ((event.clientY - rect.top) / (rect.height || 1)) - 0.5;
      hero.style.setProperty('--ss-parallax-x', x.toFixed(4));
      hero.style.setProperty('--ss-parallax-y', y.toFixed(4));
    };

    const resetParallax = () => {
      hero.style.setProperty('--ss-parallax-x', '0');
      hero.style.setProperty('--ss-parallax-y', '0');
    };

    hero.addEventListener('pointermove', updateParallax);
    hero.addEventListener('pointerleave', resetParallax);

    return () => {
      hero.removeEventListener('pointermove', updateParallax);
      hero.removeEventListener('pointerleave', resetParallax);
    };
  }, []);

  const handleThemeToggle = () => {
    setIsDarkMode((prev) => !prev);
  };

  return (
    <div className="App">
      <LandingHeader />

      <main className="ss-landing-main">
        <section className="ss-landing-hero" id="home" ref={heroRef}>
          <div className="ss-landing-colorbends-layer" aria-hidden="true">
            <ColorBends
              colors={isDarkMode ? ['#38bdf8', '#14b8a6', '#818cf8'] : ['#14b8a6', '#3b82f6', '#f97316']}
              rotation={6}
              speed={0.18}
              scale={1.08}
              frequency={1}
              warpStrength={1}
              mouseInfluence={1.35}
              parallax={0.75}
              noise={0.05}
              transparent
              autoRotate={3}
            />
          </div>
          <div className="ss-landing-grid-overlay" aria-hidden="true"></div>
          <div className="ss-landing-hero-bg"></div>
          <div className="ss-landing-orb ss-landing-orb-a"></div>
          <div className="ss-landing-orb ss-landing-orb-b"></div>
          <div className="container">
            <div className="ss-landing-hero-content">
              <div className="ss-landing-hero-text">
                <div className="ss-landing-kicker">AI-Powered Risk Detection for Filipino Shoppers</div>
                <h1 className="ss-landing-hero-title">Shop Smarter. Stay Protected.</h1>
                <p className="ss-landing-hero-subtitle">
                  SureshopPH analyzes listings, sellers, and URLs in real-time to help you identify
                  fraudulent activity before you buy — powered by localized AI built for the Philippine
                  e-commerce environment.
                </p>
                <div className="ss-landing-hero-stats">
                  <div className="ss-landing-stat-item">
                    <i className="fas fa-shield-check"></i>
                    <span>Localized Taglish NLP analysis</span>
                  </div>
                  <div className="ss-landing-stat-item">
                    <i className="fas fa-bolt"></i>
                    <span>Real-time risk scoring</span>
                  </div>
                </div>
                <div className="ss-landing-hero-buttons">
                  <a
                    href="https://github.com/JorjDominic/Browser-Extension"
                    className="btn btn-primary ss-landing-btn-primary"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <i className="fas fa-download"></i> Install Browser Extension
                  </a>
                  <a href="#demo" className="btn btn-secondary ss-landing-btn-secondary">
                    <i className="fas fa-play-circle"></i> Watch Demo
                  </a>
                  <a href="#features" className="ss-landing-btn-tertiary">
                    <i className="fas fa-chart-line"></i> Explore All Features
                  </a>
                </div>
              </div>
              <div className="ss-landing-hero-visual" aria-hidden="true">
                <div className="ss-landing-glass-card ss-landing-glass-main">
                  <h3>Risk Scan</h3>
                  <p>amazon-super-discount.example</p>
                  <div className="ss-landing-risk-meter">
                    <span>Risk Score</span>
                    <strong>87%</strong>
                  </div>
                  <div className="ss-landing-meter-bar">
                    <div className="ss-landing-meter-fill"></div>
                  </div>
                </div>
                <div className="ss-landing-glass-card ss-landing-glass-alert">
                  <i className="fas fa-triangle-exclamation"></i>
                  Suspicious seller account detected — registered 3 days ago
                </div>
                <div className="ss-landing-glass-card ss-landing-glass-safe">
                  <i className="fas fa-circle-check"></i>
                  Seller verified — high ratings and response rate
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="ss-landing-trust-strip" aria-label="Trust signals">
          <div className="container">
            <div className="ss-landing-trust-track">
              <span><i className="fas fa-bolt"></i> Real-time risk analysis on every listing</span>
              <span><i className="fas fa-shield-heart"></i> Dual Risk Score and Confidence Rating</span>
              <span><i className="fas fa-users"></i> Built for Filipino online shoppers</span>
              <span><i className="fas fa-bug-slash"></i> Supports Shopee, Lazada & Facebook Marketplace</span>
            </div>
          </div>
        </section>

        <section className="ss-landing-section ss-landing-features ss-landing-section-signature" id="features" data-section="01">
          <div className="container">
            <div className="ss-landing-section-header">
              <p className="ss-landing-eyebrow">Multi-Factor Risk Detection</p>
              <h2 className="ss-landing-section-title">Comprehensive Listing Protection</h2>
              <p className="ss-landing-section-subtitle">Analyze every layer of a listing before you commit to a purchase</p>
            </div>
            <div className="ss-landing-features-grid ss-landing-features-grid-mosaic">
              <div className="ss-landing-feature-card" data-chip="Domain Shield">
                <div className="ss-landing-feature-icon">
                  <i className="fas fa-globe"></i>
                </div>
                <h3>URL & Domain Analysis</h3>
                <p>Detect typosquatting and domain spoofing in real-time — catching fake websites designed to look like Shopee, Lazada, or other trusted platforms.</p>
              </div>
              <div className="ss-landing-feature-card" data-chip="Price Anomaly Radar">
                <div className="ss-landing-feature-icon">
                  <i className="fas fa-shopping-bag"></i>
                </div>
                <h3>Listing Metadata Scan</h3>
                <p>Flags suspicious pricing, low ratings, and abnormal sales figures — identifying "too good to be true" offers before they cost you.</p>
              </div>
              <div className="ss-landing-feature-card" data-chip="Seller DNA">
                <div className="ss-landing-feature-icon">
                  <i className="fas fa-user-shield"></i>
                </div>
                <h3>Seller Assessment</h3>
                <p>Evaluates seller account age, response rate, and aggregate ratings to surface fraudulent or newly created seller profiles.</p>
              </div>
              <div className="ss-landing-feature-card" data-chip="Taglish NLP">
                <div className="ss-landing-feature-icon">
                  <i className="fas fa-language"></i>
                </div>
                <h3>Localized NLP Analysis</h3>
                <p>Powered by calamanCy, our engine detects social engineering cues and deceptive phrasing in Tagalog and Taglish product descriptions and reviews.</p>
              </div>
              <div className="ss-landing-feature-card" data-chip="Risk Lens">
                <div className="ss-landing-feature-icon">
                  <i className="fas fa-chart-bar"></i>
                </div>
                <h3>Risk & Confidence Scores</h3>
                <p>Every scan produces a probabilistic Risk Score (0–100%) and a Confidence Rating based on data completeness — never a forced safe or scam label.</p>
              </div>
              <div className="ss-landing-feature-card" data-chip="Community Shield">
                <div className="ss-landing-feature-icon">
                  <i className="fas fa-flag"></i>
                </div>
                <h3>Community Reporting</h3>
                <p>Report suspicious listings and false positives directly through the extension, contributing to a growing database of verified high-risk scans for all Filipino shoppers.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="ss-landing-section ss-landing-how ss-landing-section-signature" id="how" data-section="02">
          <div className="container">
            <div className="ss-landing-section-header">
              <p className="ss-landing-eyebrow">Simple by Design</p>
              <h2 className="ss-landing-section-title">How SureshopPH Works</h2>
              <p className="ss-landing-section-subtitle">Three steps to safer online shopping</p>
            </div>
            <div className="ss-landing-steps">
              <div className="ss-landing-step-card">
                <div className="ss-landing-step-number">01</div>
                <div className="ss-landing-step-icon">
                  <i className="fas fa-puzzle-piece"></i>
                </div>
                <h3>Install the Extension</h3>
                <p>Add SureshopPH to any Chromium-based browser — Chrome, Edge, Brave, or Opera — in seconds.</p>
              </div>
              <div className="ss-landing-step-card">
                <div className="ss-landing-step-number">02</div>
                <div className="ss-landing-step-icon">
                  <i className="fas fa-search"></i>
                </div>
                <h3>Browse Normally</h3>
                <p>Shop on Shopee, Lazada, or Facebook Marketplace as you normally would. The extension automatically extracts listing data in the background.</p>
              </div>
              <div className="ss-landing-step-card">
                <div className="ss-landing-step-number">03</div>
                <div className="ss-landing-step-icon">
                  <i className="fas fa-shield-alt"></i>
                </div>
                <h3>Get Your Risk Score</h3>
                <p>Receive a real-time Risk Score and breakdown of detected red flags directly on the listing page — empowering you to decide with confidence.</p>
              </div>
            </div>
          </div>
        </section>

        <section className="ss-landing-section ss-landing-community ss-landing-section-signature" id="community" data-section="03">
          <div className="container">
            <div className="ss-landing-section-header">
              <p className="ss-landing-eyebrow">Community-Driven Protection</p>
              <h2 className="ss-landing-section-title">Join the SureshopPH Community</h2>
              <p className="ss-landing-section-subtitle">Filipino shoppers protecting each other from online fraud</p>
            </div>
            <div className="ss-landing-community-stats">
              <div className="ss-landing-community-stat">
                <div className="ss-landing-community-number">50K+</div>
                <p>Active Users</p>
              </div>
              <div className="ss-landing-community-stat">
                <div className="ss-landing-community-number">1M+</div>
                <p>Listings Scanned</p>
              </div>
              <div className="ss-landing-community-stat">
                <div className="ss-landing-community-number">25K+</div>
                <p>Risks Flagged</p>
              </div>
            </div>
            <div className="ss-landing-community-content">
              <div className="ss-landing-community-text">
                <h3>Collective Protection for Filipino Shoppers</h3>
                <p>Every user report strengthens the system. SureshopPH maintains a public database of high-risk scans and community-verified reports, making the Philippine digital marketplace safer for everyone.</p>
                <ul className="ss-landing-community-list">
                  <li><i className="fas fa-check-circle"></i> Report false positives and suspicious listings</li>
                  <li><i className="fas fa-check-circle"></i> Access the public high-risk scans database</li>
                  <li><i className="fas fa-check-circle"></i> View automated reports on local fraud trends</li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        <section className="ss-landing-section ss-landing-demo ss-landing-section-signature" id="demo" data-section="04">
          <div className="container">
            <div className="ss-landing-demo-content">
              <div className="ss-landing-demo-text">
                <p className="ss-landing-eyebrow">Product Walkthrough</p>
                <h2 className="ss-landing-section-title">See SureshopPH In Action</h2>
                <p className="ss-landing-demo-subtitle">Watch how SureshopPH detects risk indicators in real-time across Shopee, Lazada, and Facebook Marketplace</p>
                <div className="ss-landing-demo-features">
                  <div className="ss-landing-demo-feature">
                    <i className="fas fa-check-circle"></i>
                    <span>Live risk score demonstration</span>
                  </div>
                  <div className="ss-landing-demo-feature">
                    <i className="fas fa-check-circle"></i>
                    <span>Browser extension walkthrough</span>
                  </div>
                  <div className="ss-landing-demo-feature">
                    <i className="fas fa-check-circle"></i>
                    <span>Web dashboard tour</span>
                  </div>
                </div>
                <div className="ss-landing-demo-video">
                  <div className="ss-landing-video-placeholder">
                    <i className="fas fa-play-circle"></i>
                    <p>Demo Video Coming Soon</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <section className="ss-landing-section ss-landing-cta ss-landing-section-signature" data-section="05">
          <div className="container">
            <div className="ss-landing-cta-content">
              <p className="ss-landing-eyebrow">Your Protection Starts Here</p>
              <h2>Ready to Shop with Confidence?</h2>
              <p>Join Filipino shoppers already using SureshopPH to detect risk before it costs them.</p>
              <div className="ss-landing-cta-buttons">
                <a
                  href="https://github.com/JorjDominic/Browser-Extension"
                  className="btn btn-primary ss-landing-btn-primary"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <i className="fas fa-download"></i> Install Extension
                </a>
                <a href="register.php" className="btn btn-secondary ss-landing-btn-secondary">
                  <i className="fas fa-user-plus"></i> Create Free Account
                </a>
              </div>
            </div>
          </div>
        </section>
      </main>

      <LandingFooter />

      <button
        type="button"
        className={`ss-theme-toggle${isDarkMode ? ' is-dark' : ''}`}
        aria-label={isDarkMode ? 'Switch to light mode' : 'Switch to dark mode'}
        onClick={handleThemeToggle}
      >
        <span className="ss-theme-toggle-glow" aria-hidden="true"></span>
        <span className="ss-theme-toggle-core" aria-hidden="true">
          <i className={`fas ${isDarkMode ? 'fa-moon' : 'fa-sun'}`}></i>
        </span>
      </button>
    </div>
  );
}

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;