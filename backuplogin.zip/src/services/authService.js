import { supabase } from "../config/supabase"

// Register
export const registerUser = async (email, password) => {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
  })

  return { data, error }
}

// Login (UPDATED)
export const loginUser = async (email, password) => {
  const { data, error } = await supabase.auth.signInWithPassword({
    email,
    password,
  })

  if (error) return { data, error }

  const user = data.user

  // fetch profile (IMPORTANT)
  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user.id)
    .single()

  return {
    data: {
      user,
      profile
    },
    error: profileError
  }
}

// Logout
export const logoutUser = async () => {
  const { error } = await supabase.auth.signOut()
  return { error }
}