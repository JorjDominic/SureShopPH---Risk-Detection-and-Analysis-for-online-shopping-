import { useState } from "react"
import { Link } from "react-router-dom"
import { loginUser } from "../services/authService"

function Login() {

const [email, setEmail] = useState("")
const [password, setPassword] = useState("")
const [message, setMessage] = useState("")

const handleLogin = async (event) => {
  event.preventDefault()
  setMessage("")

  const { error } = await loginUser(email, password)

  if(error){
    setMessage(error.message)
  } else {
    setMessage("Login successful")
  }
}

return (
<main className="auth-container">
  <section className="auth-card">
    <h1>Login</h1>
    <p style={{ marginBottom: "1.5rem", color: "var(--text)" }}>
      Sign in to continue to your SureshopPH dashboard.
    </p>

    {message ? (
      <div className={message === "Login successful" ? "alert alert-success" : "alert alert-error"}>
        {message}
      </div>
    ) : null}

    <form onSubmit={handleLogin}>
      <div className="form-group">
        <label htmlFor="login-email">Email</label>
        <input
          id="login-email"
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e)=>setEmail(e.target.value)}
          required
        />
      </div>

      <div className="form-group">
        <label htmlFor="login-password">Password</label>
        <input
          id="login-password"
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e)=>setPassword(e.target.value)}
          required
        />
      </div>

      <button className="btn btn-primary btn-block" type="submit">
        Login
      </button>
    </form>

    <div className="auth-links">
      <p>
        New here? <Link to="/register">Create an account</Link>
      </p>
      <p>
        <Link to="/">Back to home</Link>
      </p>
    </div>
  </section>
</main>
)

}

export default Login