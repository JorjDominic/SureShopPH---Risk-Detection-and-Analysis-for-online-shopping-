import { useState } from "react"
import { Link } from "react-router-dom"
import { registerUser } from "../services/authService"

function Register() {
	const [email, setEmail] = useState("")
	const [password, setPassword] = useState("")
	const [confirmPassword, setConfirmPassword] = useState("")
	const [message, setMessage] = useState("")

	const handleRegister = async (event) => {
		event.preventDefault()
		setMessage("")

		if (password !== confirmPassword) {
			setMessage("Passwords do not match")
			return
		}

		const { error } = await registerUser(email, password)

		if (error) {
			setMessage(error.message)
			return
		}

		setMessage("Registration successful. Check your email for verification.")
	}

	return (
		<main className="auth-container">
			<section className="auth-card">
				<h1>Create Account</h1>
				<p style={{ marginBottom: "1.5rem", color: "var(--text)" }}>
					Register to start using SureshopPH.
				</p>

				{message ? (
					<div
						className={
							message.startsWith("Registration successful")
								? "alert alert-success"
								: "alert alert-error"
						}
					>
						{message}
					</div>
				) : null}

				<form onSubmit={handleRegister}>
					<div className="form-group">
						<label htmlFor="register-email">Email</label>
						<input
							id="register-email"
							type="email"
							placeholder="Email"
							value={email}
							onChange={(e) => setEmail(e.target.value)}
							required
						/>
					</div>

					<div className="form-group">
						<label htmlFor="register-password">Password</label>
						<input
							id="register-password"
							type="password"
							placeholder="Password"
							value={password}
							onChange={(e) => setPassword(e.target.value)}
							required
						/>
					</div>

					<div className="form-group">
						<label htmlFor="register-confirm-password">Confirm Password</label>
						<input
							id="register-confirm-password"
							type="password"
							placeholder="Confirm Password"
							value={confirmPassword}
							onChange={(e) => setConfirmPassword(e.target.value)}
							required
						/>
					</div>

					<button className="btn btn-primary btn-block" type="submit">
						Create Account
					</button>
				</form>

				<div className="auth-links">
					<p>
						Already have an account? <Link to="/login">Sign in</Link>
					</p>
					<p>
						<Link to="/">Back to home</Link>
					</p>
				</div>
			</section>
		</main>
	)
}

export default Register
